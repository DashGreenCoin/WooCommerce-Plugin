<?php

class WC_Dash_Green extends WC_Payment_Gateway{

    const CP_API_URL = "http://104.238.141.138/api/getinfo.php";

    public function __construct(){
        $this->id = 'dashgreen_payment';
        $this->method_title = __('Dash Green cryptocurrency payment','woocommerce-dashgreen');
        $this->method_description = __('Dash Green Payment Gateway allows you to receive payments in DASHG cryptocurrency','woocommerce-dashgreen');
        $this->has_fields = true;
        $this->init_form_fields();
        $this->init_settings();
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->payment_address = $this->get_option('payment_address');
        $this->confirmation_no = $this->get_option('confirmation_no');
        $this->max_time_limit = $this->get_option('max_time_limit');
        $this->cryptocurrency_used = "DASHG";
        $this->default_currency_used = get_woocommerce_currency();
        $this->exchange_rate = $this->exchange_rate($this->default_currency_used);
        $this->plugin_version = "1.0.1";

        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
    }
    public function init_form_fields(){
                $this->form_fields = array(
                    'enabled' => array(
                        'title'         => __( 'Enable/Disable', 'woocommerce-dashgreen' ),
                        'type'          => 'checkbox',
                        'label'         => __( 'Enable Dash Green Cryptocurrency Payment', 'woocommerce-dashgreen' ),
                        'default'       => 'yes'
                    ),
                    'title' => array(
                        'title'         => __( 'Method Title', 'woocommerce-dashgreen' ),
                        'type'          => 'text',
                        'default'       => __( 'Dash Green Cryptocurrency Payment', 'woocommerce-dashgreen' ),
                        'desc_tip'   => __( 'The payment method title which you want to appear to the customer in the checkout page.'),
                    ),
                    'description' => array(
                        'title' => __( 'Payment Description', 'woocommerce-dashgreen' ),
                        'type' => 'text',
                        'default' => 'Please send the exact amount in DASHG to the payment address bellow.',
                        'desc_tip'   => __( 'The payment description message which you want to appear to the customer on the payment page. You can pass a thank you note as well.' ),
                    ),
                    'payment_address' => array(
                        'title' => __( 'Dash Green Wallet Address', 'woocommerce-dashgreen' ),
                        'type' => 'text',
                        'desc_tip'   => __( 'Dash Green wallet address where you will receive DASHG from sales.' ),
                    ),
                    'confirmation_no' => array(
                        'title' => __( 'Minimum Confirmations', 'woocommerce-dashgreen' ),
                        'type' => 'text',
                        'default' => '5',
                        'desc_tip'  => __( 'Number of confirmations upon which the order will be considered as confirmed.' ),
                    ),
                     'max_time_limit' => array(
                        'title' => __( 'Maximum Payment Time (in Minutes)', 'woocommerce-dashgreen' ),
                        'type' => 'text',
                        'default' => "15",
                        'desc_tip' => __( 'Time allowed for a user to make the required payment.' ),
                    )
             );
    }

    /**
     * Admin Panel Options
     * - Options for bits like 'title' and availability on a country-by-country basis
     *
     * @since 1.0.0
     * @return void
     */
    public function admin_options() {
        ?>
            <h3><?php _e('Dash Green Payment Settings', 'woocommerce-dashgreen' ); ?></h3>
            <p>Dash Green Payment Gateway allows you to receive payments in DASHG cryptocurrency</p>
            <table class="form-table">
                <?php $this->generate_settings_html();?>
            </table>
        <?php
    }


    // Process payment
    public function process_payment( $order_id ) {

        global $woocommerce;
        $order = new WC_Order( $order_id );

         // Reduce stock levels for the product
        wc_reduce_stock_levels( $order_id );

        // Empty cart after payment
        $woocommerce->cart->empty_cart();

        // Redirect to order-pay page
        return array(
            'result' => 'success',
            'redirect' =>  $order->get_checkout_payment_url( $on_checkout = false )
           );
    }


    // Payent method structure on the checkout page
    public function payment_fields(){
        ?>
            <fieldset style="padding: 0.75em 0.625em 0.75em;">
                <table>
                    <tr style="vertical-align: middle; text-align: left;">
                        <td width="180">
                            <img alt="plugin logo" width="160" style="max-height: 40px;" src="<?php echo plugins_url('/woocommerce-dashgreen/dashgreen-plugin-logo.png') ?>">
                        </td>
                        <td>
                            <div>Exchange rate:</div>
                            <strong> 1 <?php echo $this->cryptocurrency_used; ?> = <?php echo round($this->exchange_rate, 5); ?> <?php echo $this->default_currency_used; ?></strong>
                        </td>
                    </tr>
                </table>
            </fieldset>
        <?php
    }


    // Exchange rate in the default store currency
    public function exchange_rate($default_currency) {
        if ( is_checkout() ) {
            $rate = file_get_contents(CP_API_URL ."?rate=" . $default_currency);
            return $rate;
        }
    }

}
?>
