<?php
/*
    Plugin Name: Dash Green Cryptocurrency Payment Gateway for WooCommerce
    Description: Payment Gateway for Dash Green Cryptocurrency
    Version: 1.0.1
    Author: Dash Green
    Author URI: https://dashgreen.net
    Plugin URI: https://dashgreen.net
*/

const CP_API_URL = "http://104.238.141.138/api/getinfo.php";
const CP_ORDERS_TABLE_NAME = "dashgreen_cryptocurrency_orders";

function create_transactions_table() {
    global $wpdb;
    $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $db_table_name (
              id int(11) NOT NULL AUTO_INCREMENT,
              transaction_id varchar(150) DEFAULT NULL,
              payment_address varchar(150),
              order_id varchar(250),
              order_status varchar(250),
              order_time varchar(250),
              order_total varchar(50),
              order_in_crypto varchar(50),
              order_default_currency varchar(50),
              order_crypto_exchange_rate varchar(50),
              confirmation_no int(11) DEFAULT NULL,
              PRIMARY KEY  id (id)
          ) $charset_collate;";

     require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
     $res = dbDelta( $sql );
}


// Check active plugins and see if woocommerce is installed
if ( class_exists( 'WooCommerce')) {
	register_activation_hook( __FILE__, 'create_transactions_table' );
    add_filter('woocommerce_payment_gateways', 'add_dashgreen_crypto_gateway');


    function add_dashgreen_crypto_gateway( $gateways ){
        $gateways[] = 'WC_Dash_Green';
        return $gateways;
    }

    add_action('plugins_loaded', 'init_payment_gateway');

    function init_payment_gateway(){
        require 'WC_Dash_Green.php';
    }
}
else {
    echo "<script>alert('Please install WooCommerce before proceeding')</script>";
    exit;
}

// Add plugin scripts
function load_cp_scripts() {
    if ( is_wc_endpoint_url( 'order-pay' ) ) {
        wp_enqueue_style( 'cp-styles', plugins_url('/woocommerce-dashgreen/css/cp-styles.css'));
        wp_enqueue_script( 'cp-script', plugins_url('/woocommerce-dashgreen/js/cp-script.js'));
    }
}

add_action('wp_enqueue_scripts', 'load_cp_scripts', 30);


// Processing of order
function process_order($order_id) {
    global $wp;
    $wc_dashg = new WC_Dash_Green;

    $order_id = $wp->query_vars['order-pay'];
    $order = wc_get_order($order_id);
    $order_status = $order->get_status();

    $order_crypto_exchange_rate = $wc_dashg->exchange_rate;

    // Redirect to "order received" page if the order is not pending payment
  	if($order_status !== 'pending') {
    		$redirect = $order->get_checkout_order_received_url();
    		wp_safe_redirect($redirect);
    		exit;
    }

    if ($order_crypto_exchange_rate == 0) {
        wc_add_notice( 'There is an issue with fetching information about the current rates. Please try again.', 'error' );
        wc_print_notices();
        exit;
    }


    if ($order_id > 0 && $order instanceof WC_Order) {

        global $wpdb;
        $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $db_table_name WHERE order_id = %d", $order_id));

        if ($wpdb->last_error) {
            wc_add_notice( 'There has been an error processing your order. Please try again.', 'error' );
            wc_print_notices();
            exit;
        }


        // Record the order details for the first time
        if($count == 0){

            $payment_address = $wc_dashg->payment_address;
            $order_total = $order->get_total();
            $order_in_crypto = order_total_in_crypto($order_total, $order_crypto_exchange_rate);
            $order_currency = $order->get_currency();

            $record_new = $wpdb->insert( $db_table_name, array( 'transaction_id' => "", 'payment_address' => $payment_address, 'order_id'=>$order_id, 'order_total' => $order_total, 'order_in_crypto' => $order_in_crypto, 'order_default_currency' => $order_currency, 'order_crypto_exchange_rate' => $order_crypto_exchange_rate, 'order_status' => 'pending', 'order_time'=>time()) );

            if ($wpdb->last_error) {
                wc_add_notice( 'There has been an error processing your order. Please try again.', 'error' );
                wc_print_notices();
                exit;
            }
        }
    }
}

add_action("before_woocommerce_pay", "process_order", 20);



// Verification of payment
function verify_payment() {
    global $wpdb;
    $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;

    $wc_dashg = new WC_Dash_Green;

    $order_id = $_POST['order_id'];
    $order = new WC_Order($order_id);


    $cp_order = get_cp_order_info($order_id);
    $payment_address = $cp_order->payment_address;
    $transaction_id = $cp_order->transaction_id;
    $order_in_crypto = $cp_order->order_in_crypto;
    $confirmation_no = $wc_dashg->confirmation_no;
    $order_time = $cp_order->order_time;
    $max_time_limit = $wc_dashg->max_time_limit;
    $plugin_version = $wc_dashg->plugin_version;

    if(empty($transaction_id)){
        $transaction_id = "missing";
    }
    $response = file_get_contents(CP_API_URL ."?address=" . $payment_address . "&tx=" . $transaction_id . "&amount=" . $order_in_crypto . "&conf=" . $confirmation_no . "&otime=" . $order_time . "&mtime=" . $max_time_limit . "&pv=" . $plugin_version);
    $response = json_decode($response);


    if (!empty($response)) {

        if($response->status == "invalid") {
            echo json_encode($response);
            die();
        }

        // Check if transaction is expired
        if($response->status == "expired") {
            if($cp_order->order_status != "expired") {
                $update = $wpdb->update( $db_table_name, array('transaction_id' => $response->transaction_id, 'order_status' => 'confirmed', 'confirmation_no' => $response->confirmations), array( 'order_id' => $order_id ) );
            }
        }

        // Check if transaction exists
        if($response->transaction_id != "" && strlen($response->transaction_id) == 64) {
            $transactions = $wpdb->get_results($wpdb->prepare("SELECT id FROM $db_table_name WHERE transaction_id = %s AND order_id <> %d", $response->transaction_id, $order_id));

            if ($wpdb->last_error) {
                wc_add_notice( 'Unable to process the order. Please try again.', 'error' );
                wc_print_notices();
                exit;
            }

            if (count($transactions) > 0) {
                echo json_encode(["status" => "failed"]);
                die();
            }
        }

        if($response->status == "detected") {
            if(empty($cp_order->transaction_id)) {
                $update = $wpdb->update( $db_table_name, array('transaction_id' => $response->transaction_id, 'order_status' => 'detected', 'confirmation_no' => $response->confirmations), array( 'order_id' => $order_id ) );
            }
        }

        if($response->status == "confirmed") {
            if($cp_order->order_status != "confirmed") {
                $update = $wpdb->update( $db_table_name, array('transaction_id' => $response->transaction_id, 'order_status' => 'confirmed', 'confirmation_no' => $response->confirmations), array( 'order_id' => $order_id ) );
                $order->update_status('processing');
            }
        }

        if ($wpdb->last_error) {
            wc_add_notice( 'Unable to record transaction. Please contact the shop owner.', 'error' );
            wc_print_notices();
            exit;
        }

        echo json_encode($response);
        die();
    }
    else {
        echo json_encode(["status" => "failed"]);
        die();
    }
}

add_action("wp_ajax_verify_payment", "verify_payment");
add_action("wp_ajax_nopriv_verify_payment", "verify_payment");



// Get information about the recorded order
function get_cp_order_info($order_id){
    global $wpdb;
    $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;

    $result = $wpdb->get_results($wpdb->prepare("SELECT * FROM $db_table_name WHERE order_id = %d", $order_id));

    if ($wpdb->last_error) {
        wc_add_notice( 'Unable to retrieve order details.', 'error' );
        wc_print_notices();
        exit;
    }

    return $result[0];
}


// Get information about the remaining time for order
function order_remaining_time($order_id) {
    global $wpdb;
    $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;

    $wc_dashg = new WC_Dash_Green;
    $max_time_limit = $wc_dashg->max_time_limit * 60; // In seconds

    $now = new DateTime();
    $order_time = $wpdb->get_var($wpdb->prepare( "SELECT order_time FROM $db_table_name WHERE order_id = %d", $order_id) );

    if ($wpdb->last_error) {
        wc_add_notice( 'There has been an error processing your order. Please try again.', 'error' );
        wc_print_notices();
        exit;
    }

    $time = $max_time_limit - ($now->getTimestamp() - $order_time);

    return $time;
}



// Create order total
function order_total_in_crypto($amount, $rate) {
    $diffrence = 0.00002;
    $total = round($amount / $rate, 5);

    // Create unique amount for payment
    $wc_dashg = new WC_Dash_Green;
    $max_time_limit = $wc_dashg->max_time_limit * 60;

    global $wpdb;
    $db_table_name = $wpdb->prefix . CP_ORDERS_TABLE_NAME;
    $safe_period = $max_time_limit * 3;

    $other_amounts = $wpdb->get_results("SELECT order_in_crypto FROM $db_table_name WHERE order_status <> 'confirmed' AND order_time > (UNIX_TIMESTAMP(NOW()) - $safe_period)");

    if ($wpdb->last_error) {
        wc_add_notice( 'There has been an error processing your order. Please try again.', 'error' );
        wc_print_notices();
        exit;
    }

    foreach($other_amounts as $amount){
        if($total == $amount->order_in_crypto){
            $total = round($total  + $diffrence, 5);
        }
    }

    return $total;
}



// Order received text
function isa_order_received_text( $text, $order ) {
    if ($order->has_status('completed')) {
        $new = 'Thank you. Your order has been received!';
    }
    else {
        $new = '';
    }
    return $new;
}

add_filter('woocommerce_thankyou_order_received_text', 'isa_order_received_text', 10, 2 );



function myplugin_plugin_path() {
    return untrailingslashit( plugin_dir_path( __FILE__ ) );
}

add_filter( 'woocommerce_locate_template', 'myplugin_woocommerce_locate_template', 10, 3 );



function myplugin_woocommerce_locate_template( $template, $template_name, $template_path ) {
    global $woocommerce;

    $_template = $template;

    if ( ! $template_path ) {
        $template_path = $woocommerce->template_url;
    }

    $plugin_path  = myplugin_plugin_path() . '/woocommerce/';

    $template = locate_template (
        array(
            $template_path . $template_name,
            $template_name
        )
    );

    // Get the template from plugin, if it exists
    if ( ! $template && file_exists( $plugin_path . $template_name ) ) {
        $template = $plugin_path . $template_name;
    }

    // Use default template
    if ( ! $template ) {
        $template = $_template;
    }

    // Return template
    return $template;
    }

?>
